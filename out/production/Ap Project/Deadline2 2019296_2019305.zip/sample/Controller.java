package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.io.IOException;


public class Controller extends Main {

    public void pressButton(ActionEvent event)
    {
        System.out.println("functionality yet to be written");
    }
    public void playButton(ActionEvent event) throws IOException
    {
        Pane root1 = FXMLLoader.load(getClass().getResource("gamescreen.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("Pause Window");
        window.setScene(new Scene(root1 , 400, 800));
        window.show();

    }

    public void homeButton(ActionEvent event) throws Exception
    {
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        start(window);
        window.show();
    }

    public void exitButton(ActionEvent event) throws Exception
    {
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        start(window);
        window.close();
    }

    public void helpButton(ActionEvent event) throws Exception
    {
        Pane root1 = FXMLLoader.load(getClass().getResource("HelpWindow.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("Help Window");
        window.setScene(new Scene(root1 , 400, 800));
        window.show();
    }

    public void pauseButton(ActionEvent event) throws Exception
    {
        Pane root1 = FXMLLoader.load(getClass().getResource("pauseWindow.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("Pause Window");
        window.setScene(new Scene(root1 , 400, 800));
        window.show();
    }

    public void continueButton(ActionEvent event) throws Exception
    {
        Pane root1 = FXMLLoader.load(getClass().getResource("gamescreen.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("game Window");
        window.setScene(new Scene(root1 , 400, 800));
        window.show();
    }

    public void settingButton(ActionEvent event) throws Exception
    {
        Pane root1 = FXMLLoader.load(getClass().getResource("setting.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("setting Window");
        window.setScene(new Scene(root1 , 400, 800));
        window.show();
    }
    public void settingButtonP(ActionEvent event) throws Exception
    {
        Pane root1 = FXMLLoader.load(getClass().getResource("setting_pause.fxml"));
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("setting Window");
        window.setScene(new Scene(root1 , 400, 800));
        window.show();
    }






}
