package sample;

import javafx.animation.RotateTransition;
import javafx.application.Application;
import java.io.FileInputStream;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application{

    private void setRotate(ImageView iv , int angle , int dur)
    {
        RotateTransition rt = new RotateTransition();

        rt.setAxis(Rotate.Z_AXIS);

        rt.setByAngle(angle);

        rt.setCycleCount(500);

        rt.setDuration(Duration.millis(dur));

        rt.setNode(iv);

        rt.play();
    }

    @Override
    public void start(Stage primaryStage) throws Exception{

        Pane root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
        primaryStage.setTitle("Color Switch Game");

        //Creating an image
        Image img1 = new Image(new FileInputStream("D:\\Ap Project\\src\\sample\\images\\circle (2).png"));
        Image img2 = new Image(new FileInputStream("D:\\Ap Project\\src\\sample\\images\\circle-cropped.png"));
        Image img3 = new Image(new FileInputStream("D:\\Ap Project\\src\\sample\\images\\circle-cropped - Copy.png"));
        Image img4 = new Image(new FileInputStream("D:\\Ap Project\\src\\sample\\images\\circle-cropped - Copy (2).png"));

        //Setting the image view
        ImageView c1 = new ImageView(img1);
        ImageView c2 = new ImageView(img1);
        ImageView c3 = new ImageView(img2);
        ImageView c4 = new ImageView(img3);
        ImageView c5 = new ImageView(img4);

        //Setting the position of the image
        c1.setX(127);
        c1.setY(26);
        c2.setX(222);
        c2.setY(26);
        c3.setX(7);
        c3.setY(180);
        c4.setX(55);
        c4.setY(230);
        c5.setX(93);
        c5.setY(268);


        //setting the fit height and width of the image view
        c1.setFitHeight(52);
        c1.setFitWidth(61);
        c2.setFitHeight(52);
        c2.setFitWidth(61);
        c3.setFitHeight(387);
        c3.setFitWidth(393);
        c4.setFitHeight(298);
        c4.setFitWidth(290);
        c5.setFitHeight(213);
        c5.setFitWidth(221);

        //Setting the preserve ratio of the image view
        c1.setPreserveRatio(true);
        c2.setPreserveRatio(true);
        c3.setPreserveRatio(true);
        c4.setPreserveRatio(true);
        c5.setPreserveRatio(true);


        setRotate(c1 , -360 , 5000);
        setRotate(c2 , 360 , 5000);
        setRotate(c3 , 360 , 5000);
        setRotate(c4 , -360 , 5000);
        setRotate(c5 , 360 , 5000);


        root.getChildren().addAll(c1);
        root.getChildren().addAll(c2);
        root.getChildren().addAll(c3);
        root.getChildren().addAll(c4);
        root.getChildren().addAll(c5);

        primaryStage.setScene(new Scene(root , 400, 800));
        primaryStage.show();

    }

    public static void main(String[] args) throws Exception {
        launch(args);
    }
}
